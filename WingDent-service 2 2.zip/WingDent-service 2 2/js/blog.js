
/*  Blog page blogs popups javascript code Start */
function showPopup1() 
{
    // Display the overlay when the "Read More" button is clicked
    document.getElementById('popupOverlay1').style.display = 'flex';
}
function hidePopup1() 
{
    // Hide the overlay when the "Close" button is clicked
    document.getElementById('popupOverlay1').style.display = 'none';
}
function showPopup2() 
{
    // Display the overlay when the "Read More" button is clicked
    document.getElementById('popupOverlay2').style.display = 'flex';
}
function hidePopup2() 
{
    // Hide the overlay when the "Close" button is clicked
    document.getElementById('popupOverlay2').style.display = 'none';
}
function showPopup3() 
{
    // Display the overlay when the "Read More" button is clicked
    document.getElementById('popupOverlay3').style.display = 'flex';
}
function hidePopup3() 
{
    document.getElementById('popupOverlay3').style.display = 'none';
}
function showPopup4() 
{
    // Display the overlay when the "Read More" button is clicked
    document.getElementById('popupOverlay4').style.display = 'flex';
}
function hidePopup4() 
{
    // Hide the overlay when the "Close" button is clicked
    document.getElementById('popupOverlay4').style.display = 'none';
}
function showPopup5() 
{
    // Display the overlay when the "Read More" button is clicked
    document.getElementById('popupOverlay5').style.display = 'flex';
}
function hidePopup5() 
{
    // Hide the overlay when the "Close" button is clicked
    document.getElementById('popupOverlay5').style.display = 'none';
}
function showPopup6() 
{
    // Display the overlay when the "Read More" button is clicked
    document.getElementById('popupOverlay6').style.display = 'flex';
}
function hidePopup6() 
{
    // Hide the overlay when the "Close" button is clicked
    document.getElementById('popupOverlay6').style.display = 'none';
}
/*  Blog page blogs popups javascript code End */